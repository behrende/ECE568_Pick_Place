# red,green,blue cube detection > 2025-03-30 8:07am
https://universe.roboflow.com/alexlinys/red-green-blue-cube-detection-za1vb

Provided by a Roboflow user
License: CC BY 4.0

